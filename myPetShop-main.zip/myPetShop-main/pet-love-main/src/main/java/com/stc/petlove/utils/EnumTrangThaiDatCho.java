package com.stc.petlove.utils;

/**
 * Created by: IntelliJ IDEA
 * User      : thangpx
 * Date      : 4/11/23
 * Time      : 9:43 PM
 * Filename  : EnumTrangThaiDatCho
 */
public enum EnumTrangThaiDatCho {
    HUY,
    DAT_CHO,
    DANG_THUC_HIEN,
    HOAN_THANH;
}
