package com.stc.petlove;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetLoveApplication {

    public static void main(String[] args) {
        SpringApplication.run(PetLoveApplication.class, args);
    }

}
